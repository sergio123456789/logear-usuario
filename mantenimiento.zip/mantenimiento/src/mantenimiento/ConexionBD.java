/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mantenimiento;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author sergio
 */
public class ConexionBD {

    private static final String url = "jdbc:mysql://localhost:3306/mibdd";
    private static final String usuario = "";
    private static final String clave= "";
    

public static Connection Conexion()
{
 try{
 return DriverManager.getConnection(url,usuario,clave);

}
catch(SQLException e)
{
System.err.println("Excepción de SQL: "+e);
return null;
}
}
}

